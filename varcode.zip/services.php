<!DOCTYPE html>
<html lang="en">
   <head>
      <title>Services | Freelancing web developer in Hyderabad.</title>
      <?php include("header.php"); ?>
      <div class="camel">
          <div class="image-bg"></div>
          <div class="container services">
              <h2 id="animated_div">Services</h2>
             <marquee>Services will be updated soon ! Thank you for visiting.</marquee>
          </div>
          </div>
          
          <?php include("footer.php"); ?>