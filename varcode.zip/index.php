<!DOCTYPE html>
<html lang="en">

<head>
    <title>Ram - Web Developer | Freelancer | HTML,CSS</title>
    <?php include("header.php"); ?>
    <div class="jumbotron text-center hero">
        <div class="overlay">
            <h1>THE CODER</h1>
            <h4>Coding is a never ending process.</h4>
            <h4 class="text-capitalize">Everything is possible, Even the word Impossible says I'm possible!</h4>
            <marquee>
                <p id="boxContent">
                    <?php
                        include "dbconfig.php";
                        $select_query = "select * from latestnews";
                        $select_exq = mysql_query($select_query);

                        while ($select_Data = mysql_fetch_array($select_exq))
                            {
                                $lnews = $select_Data['news'];
                                echo "<span><img src='./vcfiles/newgif.gif' style='max-width:30px'; /></span> $lnews ";
                            }
                    ?>
                </p>
            </marquee>
        </div>
    </div>
    <div class="clearfix"></div>
    <div class="container">
        <div class="row">
            <div class="col-sm-4">
                <h3>Set Your Goal</h3>
                <p>Many Students after completion of their studies, they will do two things.</p>
                <ul class="" type="circle">
                    <li>Wasting Time</li>
                    <li>Utilizing time but they dont know what's their goal</li>
                </ul>
            </div>
            <div class="col-sm-4">
                <h3>Focus On It</h3>
                <p>Before starting anything without knowing, Make/Get an idea from others. </p>
                <p>Don't blindly follow what they said, Just think of what they telling and try to filter one solution
                    from that.</p>
            </div>
            <div class="col-sm-4">
                <h3>Proove It</h3>
                <p>After making your goals start working on it. Once if you start working on it don't care what others
                    think about you. Just judge youself and proove it like '<span class="lead">I CAN</span>'</p>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
    <section class="webdev">
        <div class="container">
            <div class="row">
            </div>
        </div>
    </section>
    <div class="clearfix"></div>
    <section class="webdev2 rain">
        <div class="container">
            <h2 class="text-center text-success">Technologies Offered</h2>
            <p>Following Technologies here i'm going to offer <span
                    style='font-size: 45px; vertical-align: -webkit-baseline-middle;line-height: 22px;'>&#9759;</span>
            </p>
            <div class="row">
                <div class="col-sm-4">
                    <h3>HTML 5</h3>
                </div>
                <div class="col-sm-4">
                    <h3>CSS 3</h3>
                </div>
                <div class="col-sm-4">
                    <h3>BOOTSTRAP</h3>
                </div>
                <div class="col-sm-4">
                    <h3>jQuery</h3>
                </div>
                <div class="col-sm-4">
                    <h3>Javascript</h3>
                </div>
                <div class="col-sm-4">
                    <h3>PHP</h3>
                </div>
            </div>
        </div>
    </section>
    <div class="clearfix"></div>
    <?php include('footer.php'); ?>
    <!-- <script>
          // number of drops created.
var nbDrop = 100; 
// function to generate a random number range.
function randRange( minNum, maxNum) {return (Math.floor(Math.random() * (maxNum - minNum + 1)) + minNum);}
// function to generate drops
function createRain() {
    for( i=1;i<nbDrop;i++) {
    var dropLeft = randRange(0,1600);
    var dropTop = randRange(-1000,1400);
    $('.rain').append('<div class="drop" id="drop'+i+'"></div>');
    $('#drop'+i).css('left',dropLeft);
    $('#drop'+i).css('top',dropTop);
    }
}
// Make it rain
createRain();
      </script> -->