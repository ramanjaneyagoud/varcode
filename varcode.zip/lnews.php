<?php

include "dbconfig.php";

if(isset($_POST['submit'])){
    $news = $_POST['lnews'];
    
    $queryy = "insert into latestnews(news)values('$news')";
    $exqq = mysql_query($queryy);
    if($exqq){
         echo '<script>alert("News post successfully.");</script>';
        echo '<script>location.href="index.php";</script>';
    }
}


