<?php

if(isset($_POST["submit"]))
{
$to = 'ramanjaneya219@gmail.com';
$subject = 'Varcode';
$from = '.$_POST["email"].';

 
// To send HTML mail, the Content-type header must be set
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
 
// Create email headers
$headers .= 'From: '.$_POST["email"]."\r\n".
    'Reply-To: '.$_POST["email"]."\r\n" .
'X-Mailer: PHP/' . phpversion();
 
// Compose a simple HTML email message
$message = '<html><body>';
$message .= '<table border="1"  cellpadding="10px" cellspacing="10px" style="width: 100%;border: 5px solid #ff6700;">
<tbody>
<tr>
<td>Name</td> <td>'.$_POST["name"].'</td>
</tr>

<tr>
<td>Email</td> <td>'.$_POST["email"].'</td>
</tr>

<tr>
<td>Phone</td> <td>'.$_POST["phone"].'</td>
</tr>

<tr>
<td>Message</td> <td>'.$_POST["message"].'</td>
</tr>
</tbody>
</table>';

$message .= '</body></html>';
 
// Sending email
if(mail($to, $subject, $message, $headers)){
    echo '<script>alert("Your mail has been sent successfully.");</script>';
    echo '<script>location.href="contact.php";</script>';


} 
else{
    echo '<script>alert("Unable to send email. Please try again.");</script>';
    echo '<script>location.href="contacts.php";</script>';
}
}
?> 
