<footer class="footer1">
         <div class="container">
            <div class="row">
               <div class="col-sm-3">
                  <div class="text-center">
                     <h2>Services:</h2>
                     <ul class="list-unstyled text-left">
                        <li>Creating Static & Dynamic Websites</li>
                        <li>Freelancing Works</li>
                        <li>Training on Web development</li>
                     </ul>
                  </div>
               </div>
               <div class="col-sm-3">
                  <div class="text-center">
                     <h2>Call Me:</h2>
                     <p><span style='font-size:40px;line-height:22px;'>&#9743;</span> +91-9494074924</p>
                     <p><span style='font-size:40px;line-height:22px;'>&#9993;</span> <a href="mailto:karthikviolen@gmail.com">karthikviolen@gmail.com</a></p>
                  </div>
               </div>
               <div class="col-sm-6">
                  <div style="overflow:hidden;width: 100%;position: relative;">
                     <iframe width="100%" height="250" src="https://maps.google.com/maps?width=320&amp;height=440&amp;hl=en&amp;q=Lakshmi%20Sai%20Meadows%2CBeeramguda%2C%20Hyderabad+(varcode)&amp;ie=UTF8&amp;t=&amp;z=15&amp;iwloc=B&amp;output=embed"
                        frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>
                     <div style="position: absolute;width: 80%;bottom: 10px;left: 0;right: 0;margin-left: auto;
                        margin-right: auto;color: #000;text-align: center;"><small style="line-height: 1.8;font-size: 2px;background: #fff;">Powered by 
                        <a href="https://embedgooglemaps.com/es/">Embedgooglemaps.com/es/</a> & <a href="http://abtof.org.uk/">cheapflightwebsites (en)</a>
                        </small>
                     </div>
                     <style>#gmap_canvas img{max-width:none!important;background:none!important}</style>
                  </div>
                  <br />
               </div>
            </div>
         </div>
         <div class="copyrights text-center"><p>&copy; 2019 VARCODE.&nbsp; All Rights Reserved.</p></div>
      </footer>
            <!--Start of Tawk.to Script-->
            <script type="text/javascript">
         var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
         (function(){
         var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
         s1.async=true;
         s1.src='https://embed.tawk.to/5c92824a101df77a8be3a0cd/default';
         s1.charset='UTF-8';
         s1.setAttribute('crossorigin','*');
         s0.parentNode.insertBefore(s1,s0);
         })();
      </script>
      <!--End of Tawk.to Script-->
   </body>
</html>