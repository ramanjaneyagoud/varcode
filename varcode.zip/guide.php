<!DOCTYPE html>
<html lang="en">
   <head>
      <title>Developer Guide | Freelancing web developer in Hyderabad.</title>
      <?php include("header.php"); ?>
      <div class="page-header guide pt-5 pb-5">
         <div class="container">
            <h2 class="text-center">Useful Scripts & Styles</h2>
            <div class="box">
               <h3>How to remove/select last few words using javascript</h3>
               <p>By Using javascript we can able to select last few words. Here we are using RegEx to do this.</p>
               <p><code>d.replace(/(\s+\w+){4}[.!?]?$/,'')</code></p>
               <p>Here, 'd' is the selector to which we need to apply.</p>
               <p>Final result:  we are selecting last four words in a statement and we are making it to empty.</p>
               <p>If we want to replace last four words use the below</p>
               <p><code>d.replace(/(\s+\w+){4}[.!?]?$/,'Thank you for visiting Varcode.online')</code></p>
            </div>
            <div class="box">
               <h3> Using Javascript How to remove/select first four words</h3>
               <p>By Using javascript we can able to select first few words. Here we are using RegEx to do this.</p>
               <p><code>d.replace(/^([^ ]+ ){4}/, '')</code></p>
               <p>Here, 'd' is the selector to which we need to apply.</p>
               <p>Final result:  we are selecting first four words in a statement and we are making it to empty.</p>
               <p>If we want to replace last four words use the below</p>
               <p><code>d.replace(/^([^ ]+ ){4}/, 'Thank you for visiting Varcode.online')</code></p>
            </div>
            <div class="box">
               <h3>How to call multiple google font-families through script</h3>
               <p>Generally we'll call '<u></u>Free Google Font Family</u>' using link tag in head section.</p>
               <p>Here i'm showing you an alternative way to call multiple font-families using javascript.</p>
               <p>Basically we are making AJAX calls to load font-families</p>
               <code>function loadFont(url) {<br>
                      var xhr = new XMLHttpRequest();<br>
                      xhr.open('GET', url, true);<br>
                      xhr.onreadystatechange = function () {<br>
                        if (xhr.readyState == 4 && xhr.status == 200) {<br>
                          var css = xhr.responseText;<br>
                          css = css.replace(/}/g, 'font-display: swap; }');<br>
                    
                          var head = document.getElementsByTagName('head')[0];<br>
                          var style = document.createElement('style');<br>
                          style.appendChild(document.createTextNode(css));<br>
                          head.appendChild(style);<br>
                        }<br>
                      };<br>
                      xhr.send();<br>
                    }<br>
                loadFont('https://fonts.googleapis.com/css?family=Raleway:500,600,700');</code>
            </div>
         </div>
      </div>
      <?php include("footer.php"); ?>