<!DOCTYPE html>
<html lang="en">

<head>
    <title>About Us | Freelancing web developer in Hyderabad.</title>
    <?php include("header.php"); ?>
        <!--    <div class="page-header aboutus pt-5 pb-5">-->
        <!--        <div class="overlay">-->
        <!--        <div class="container">-->
        <!--            <h2>About Me</h2>-->
        <!--            <p><span class="first-letter">H</span>ello All,</p>-->
        <!--            <p>This is <span class="lead font-italic">Ram !</span> Lives in Hyderabad. Currently working as a web developer. and i'm also working as a freelancing developer.</p>-->
        <!--            <p>As a web developer, my first concern is to create/build a responsive websites (both static & dynamic), which satisfies all screens. </p>-->
        <!--            <p>My first motto to build a responsive website is "Page Speed" , For example if any website taking long time lo load user can shift to another website. To avoid that here we'll use external stylesheets and external js files. and most part will be done by Css & Client side javascript programming. This causes to reduce the burden on server. </p>-->
        <!--        </div>-->
        <!--    </div>-->
        <!--</div>-->

        <div class="one">
            <div class="page-header p-2">
                <h2>About Me</h2>
                <p><span class="first-letter">H</span>ello All,</p>
                <p>This is <span class="lead font-italic">Ram !</span> Lives in Hyderabad. Currently working as a web developer. And also working as a freelancer.</p>
                <p>As a web developer, my first concern is to create/build a responsive websites (both static & dynamic), which satisfies all screens. </p>
            <p>My first motto to build a responsive website with good "Page Speed" , For example if any website taking long time to load user can shift to another website. To avoid that here we'll use external stylesheets and external js files and most part will be done by Css & Client side javascript programming. This reduces to reduce the burden on server. </p>
                    </div>
            <div class="overla">
                <img src="/vcfiles/ram_1.jpg" alt="Ram" class="w-100 img-responsive img_animate mt-5 p-2" />
            </div>
        </div>

        <!-- WhatsHelp.io widget -->
        <script type="text/javascript">
            (function() {
                var options = {
                    whatsapp: "+91 9494074924", // WhatsApp number
                    call_to_action: "Message us", // Call to action
                    position: "left", // Position may be 'right' or 'left'
                };
                var proto = document.location.protocol,
                    host = "whatshelp.io",
                    url = proto + "//static." + host;
                var s = document.createElement('script');
                s.type = 'text/javascript';
                s.async = true;
                s.src = url + '/widget-send-button/js/init.js';
                s.onload = function() {
                    WhWidgetSendButton.init(host, proto, options);
                };
                var x = document.getElementsByTagName('script')[0];
                x.parentNode.insertBefore(s, x);
            })();
        </script>
        <!-- /WhatsHelp.io widget -->
        <?php include("footer.php"); ?>