<?php 


$host = "localhost";
$user = "varcode_admin";
$password = "varcodeC0mpute$";
$dbname = "varcode_formdata";
mysql_connect($host,$user,$password);
mysql_select_db($dbname);


?>