<?php

include "dbconfig.php";

$select_query = "select * from latestnews";
$select_exq = mysql_query($select_query);

echo "<marquee>";
while($select_Data = mysql_fetch_array($select_exq))
{
    $lnews = $select_Data['news'];
    echo "<p>'.$lnews'</p>"
    
}
echo "</marquee>";

?>