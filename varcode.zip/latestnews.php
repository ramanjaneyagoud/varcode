<!doctype html>
<head>
    <title>Latest Posts| Freelancing web developer in Hyderabad.</title>
    <?php include("header.php"); ?>
<div class="container my-5">
    <h2>Latest News: </h2>
<form method="post" action="lnews.php">
<textarea name="lnews" rows="5" cols="50" class="form-control"></textarea>

<input type="submit" name="submit" class="mt-3 btn btn-primary"/>
</form>

</div>
   <?php include("footer.php"); ?>