
<!doctype html>
<html>
    <head>
        <title>Ramanjaneya Goud</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <style>
            body{background: url('images/Ram logo_12.jpg') no-repeat center fixed;background-color: inherit; background-size: cover;width: 100%; height: 100vh; background-position: top center;}
            #myPage,#about,#skill{height: 100vh;
                                  /*                           background: rgba(6, 6, 6, 0.67);*/
                                  display: flex;
                                  justify-content:center;align-items:center;color: #fff;}
            .pagecontent{max-width: 1060px;width: 100%;margin: 0 auto;}
            .aboutcontent p{font-size: 24px;line-height: 1.6;}
            #about{background: rgba(0,0,0,0.8);}
            #contact{height: 100vh;display: flex;   justify-content: center; align-items: center;}


            .portflex-cover { height: 100vh; display: table; width: 100%; }

            .portflex{
                display: table-cell;vertical-align: middle;
            }
            #contact1,.formdata{font-size: 24px;padding: 20px 40px; color: #fff;}
            #contact1 .glyphicon {font-size: 30px;}
            label{color: #fff;}
            .navbar-brand{padding: 8px 15px;}
            .formflex {display: flex; flex-flow: row wrap;  margin: -8px; }
            .formflex .col-sm-6 {display: flex; flex: 1 0 400px; flex-flow: column; margin: 10px;}
            .contact1,.formdata{display: flex; padding: 20px; color: white; align-items: stretch; flex-direction: column; flex-grow: 1; }
            .contactinfo{ background: rgba(6, 6, 6, 0.67); border-radius: 10px;}
            .port:hover{
                /*                opacity: 0.6; 
                                background: rgb(255,0,0,0.4)*/
                transform: scale(1.1);
                transition-duration: 1s;

            }
            .navbar-default .navbar-nav>li>a:focus, .navbar-default .navbar-nav>li>a:hover{color: #fff;}
            #myNavbar .navbar-nav>li:hover:after {
                transform: scaleX(1);
            }

            #myNavbar .navbar-nav>li:after {
                display: block;
                content: '';
                border-bottom: 2px solid #00BBD3;
                transform: scaleX(0);
                transition: transform 400ms ease-in-out;
            }

            @media(min-width:767px){body{overflow-x: auto; overflow-y: hidden;}
                                    .porthead{font-size: 40px; text-align: center; font-weight: bold; margin-bottom: 40px;color:#fff;}}
            </style>
            <style>
            .fline{position: relative;-webkit-animation-name:fline1; -webkit-animation-duration: 1.5s;-webkit-animation-delay: 0.2s;animation-name: fline1;transition: .6s ease-in-out;animation-duration: 1.5s;animation-delay: 0.2s;}

            .fline span{
                font-size: 80px;font-weight: bolder;
                /*  background: linear-gradient(to right, #00c2eb 20%, #00ff9c 40%, #00ff9c 60%, #00c2eb 80%); background-size: 200% auto; background-clip: text; -webkit-background-clip: text; -webkit-text-fill-color: transparent;font-weight: bold;font-family: 'Faster One', cursive;*/
            }


            .secline{position: relative;-webkit-animation-name:secline1; -webkit-animation-duration: 1s;-webkit-animation-delay: 0.4s;animation-name: secline1;transition: .6s ease-in-out;animation-duration: 1s;animation-delay: 0.4s;}

            .thirdline{text-align: justify;position: relative;-webkit-animation-name:thirdline1; -webkit-animation-duration: 1s;-webkit-animation-delay: 0.6s;animation-name: thirdline1;transition: .6s ease-in-out;animation-duration: 1s;animation-delay: 0.6s;}

            @keyframes fline1{
                0% {top:-600px;opacity:0;}
                100% {top:0px;opacity:1;}
            }
            @keyframes secline1{
                0% {left:-600px;opacity:0;}
                100% {left:0px;opacity:1;}
            }
            @keyframes thirdline1{
                0% {bottom:-600px;opacity:0;}
                100% {bottom:0px;opacity:1;}
            }
            @media(min-width:767px){
                .fline{font-size:60px;}
                .fline span{display: inline-block;padding: 1px;}
                .secline{font-size:65px;font-weight: bolder;margin-top: -15px;}
                .thirdline{font-size:35px;font-weight: bold;}

            }
            .slideanim{visibility: hidden;}
            .slide {
                animation-name: slide;
                -webkit-animation-name: slide;
                animation-duration: 1s;
                -webkit-animation-duration: 1s;
                visibility: visible;
            }
            @keyframes slide {
                0% {
                    opacity: 0;
                    transform: translateY(70%);
                } 
                100% {
                    opacity: 1;
                    transform: translateY(0%);
                }
            }
            @-webkit-keyframes slide {
                0% {
                    opacity: 0;
                    -webkit-transform: translateY(70%);
                } 
                100% {
                    opacity: 1;
                    -webkit-transform: translateY(0%);
                }
            }

            .navbar-default{background: rgba(6, 6, 6, 0.3);border: none;}
            .navbar-default .navbar-nav>li>a {
                color: #fff;
                font-weight: bold;
            }
            ul.h2 li:before {
                background-image: url(images/skype.png);
                content: '';
                width: 20px;
                height: 46px;
                background-repeat: no-repeat;
                background-size: 30px 26px;
                display: inline-block;
                padding-right: 53px;
                background-position: 3px 22px;
            }
            .skillcover{background: rgba(0,0,0,0.56); border-radius: 20px; padding: 20px;}
            .progress-bar-striped, .progress-striped .progress-bar{    background-size: 10px 16px;}
            .progress-bar{    background-color: rgba(185, 93, 14, 0.86);
                              font-size: 22px;   font-weight: bold;}
            .lists li{font-size: 20px;}

            /*.contactinfo{
                .draw {
              -webkit-transition: color 0.25s;
              transition: color 0.25s;
            }
            .draw::before, .draw::after {
              border: 2px solid transparent;
              width: 0;
              height: 0;
            }
            .draw::before {
              top: 0;
              left: 0;
            }
            .draw::after {
              bottom: 0;
              right: 0;
            }
            .draw:hover {
              color: #60daaa;
            }
            .draw:hover::before, .draw:hover::after {
              width: 100%;
              height: 100%;
            }
            .draw:hover::before {
              border-top-color: #60daaa;
              border-right-color: #60daaa;
              -webkit-transition: width 0.25s ease-out, height 0.25s ease-out 0.25s;
              transition: width 0.25s ease-out, height 0.25s ease-out 0.25s;
            }
            .draw:hover::after {
              border-bottom-color: #60daaa;
              border-left-color: #60daaa;
              -webkit-transition: border-color 0s ease-out 0.5s, width 0.25s ease-out 0.5s, height 0.25s ease-out 0.75s;
              transition: border-color 0s ease-out 0.5s, width 0.25s ease-out 0.5s, height 0.25s ease-out 0.75s;
            }
            
            .meet:hover {
              color: #fbca67;
            }
            .meet::after {
              top: 0;
              left: 0;
            }
            .meet:hover::before {
              border-top-color: #fbca67;
              border-right-color: #fbca67;
            }
            .meet:hover::after {
              border-bottom-color: #fbca67;
              border-left-color: #fbca67;
              -webkit-transition: height 0.25s ease-out, width 0.25s ease-out 0.25s;
              transition: height 0.25s ease-out, width 0.25s ease-out 0.25s;
            }
            }*/
        </style>


    </head>
    <body>
        <nav class="navbar navbar-default navbar-fixed-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>                        
                    </button>
                    <!--                    <a class="navbar-brand"  href="#myPage">
                                            <img src="RMLOGO1.png" alt="ram" class="img-responsive"/>
                                        </a>-->
                </div>
                <div class="collapse navbar-collapse" id="myNavbar">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="#myPage">HOME</a></li>
                        <li><a href="#about">ABOUT</a></li>
                        <li><a href="#tour">PORTFOLIO</a></li>
                        <li><a href="#skill">SKILL SET</a></li>
                        <li><a href="#contact">GET QUOTE</a></li>

                        <!--                        <li class="dropdown">
                                                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">MORE
                                                        <span class="caret"></span></a>
                                                    <ul class="dropdown-menu">
                                                        <li><a href="#">Merchandise</a></li>
                                                        <li><a href="#">Extras</a></li>
                                                        <li><a href="#">Media</a></li> 
                                                    </ul>
                                                </li>
                                                <li><a href="#"><span class="glyphicon glyphicon-search"></span></a></li>-->
                    </ul>
                </div>
            </div>
        </nav>

        <div style="clear:both;"></div>


        <!--**************************Intro Section**************************************-->

        <div id="myPage">
            <div class="pagecontent">
                <p class="fline">Hello! This is <span>RAM</span></p>
                <h2 class="secline">WordPress & Front-end Developer</h2>
                <h3 class="thirdline">Producing high quality responsive websites and exceptional user experience unconditionally for the past five Years. Delivering top notch mobile responsive website with 5* User experience.</h3>
            </div>
        </div>

        <!--**************************Intro Section**************************************-->



        <!--**************************About Section**************************************-->

        <div id="about">
            <div class="aboutcontent container">
                <h2 class="text-uppercase">Ramanjaneya Goud G</h2>
                <ul class="list-unstyled h2 lists">
                    <li>Currently working as a full-time Wordpress & Front End Developer.</li>
                    <li>Passion for innovation in the field of developing.</li>
                    <li>Expert on HTML, CSS, Javascript, Bootstrap, & Jquery.</li>
                    <li>Looking forward to serve clients on a freelance basis as a Web Developer. </li>
                    <li>  Attention to detail and commitment to quality is what I stand for.</li>
                </ul>
            </div>
        </div>

        <!--**************************End About Section**************************************-->

        <style>

        </style>

        <!--**************************Portfolio Section**************************************-->

        <div class="portfolio" id="tour">

            <div class="container">

                <div class="portflex-cover">

                    <div class="portflex">
                        <h2 class="porthead text-uppercase">portfolio</h2>
                        <div class="col-sm-4">
                            <div class="port img-thumbnail slideanim">
                                <a href="#">
                                    <img src="images/berry.jpg" class="img-responsive center-block" alt="berry"/>
                                </a>
                            </div>
                        </div>

                        <div class="col-sm-4">
                            <div class="port img-thumbnail slideanim">
                                <a href="#">
                                    <img src="images/berry.jpg" class="img-responsive center-block" alt="berry"/>
                                </a>
                            </div>
                        </div>

                        <div class="col-sm-4">
                            <div class="port img-thumbnail slideanim">
                                <a href="#">
                                    <img src="images/berry.jpg" class="img-responsive center-block" alt="berry"/>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



        <!--**************************End Portfolio Section**************************************-->




        <style>
            #skill .container{max-width: 800px; width: 100%;}
            .skillcover{padding: 20px;}
            @media(max-width:767px){.formflex .col-sm-6 { display: block;  word-break: break-all; margin: 10px;     flex: initial;}}
        </style>

        <!--**************************End Portfolio Section**************************************-->
        <div class="skillset" id="skill">

            <div class="container">

<!--                <img src="SKILLSET.png"  alt="graph"  class="img-responsive center-block" />-->
                <div class="skillcover">  <h2 style="text-align:center;font-weight: bold;">SKILL SET</h2>
                    <h3>HTML</h3>
                    <div class="progress">
                        <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100" style="width:95%">
                            95%
                        </div>
                    </div>

                    <h3>CSS</h3>
                    <div class="progress">
                        <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style="width:90%">
                            90%
                        </div>
                    </div>

                    <h3>JQUERY</h3>
                    <div class="progress">
                        <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style="width:75%">
                            75%
                        </div>
                    </div>

                    <h3>BOOTSTRAP</h3>
                    <div class="progress">
                        <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style="width:90%">
                            90%
                        </div>
                    </div>

                    <h3>JAVASCRIPT</h3>
                    <div class="progress">
                        <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:70%">
                            70%
                        </div>
                    </div>

                    <h3>WORDPRESS</h3>
                    <div class="progress">
                        <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:70%">
                            70%
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <!--**************************End Portfolio Section**************************************-->

        <!--**************************Contact Section**************************************-->

        <div style="clear:both;"></div>

        <div class="contact"   id="contact">
            <div class="container">
                <div class="row formflex">
                    <div class="col-sm-6 contactinfo">
                        <div id="contact1">
                            <div class='row'>
                                <div class="col-xs-2 text-center"> <span class="glyphicon glyphicon-user"></span></div>
                                <div class="col-xs-10"> Ramanjaneya Goud G</div>
                            </div>
                            <div class='row'>
                                <div class="col-xs-2 text-center"> <span class="glyphicon glyphicon-envelope"></span></div>
                                <div class="col-xs-10"> ramanjaneya219@gmail.com</div>
                            </div>
                            <div class='row'>
                                <div class="col-xs-2 text-center"><img src='images/skype.png'/></div>
                                <div class="col-xs-10"> ramanjaneya.goud1</div>
                            </div>
                            <div class='row'>
                                <div class="col-xs-2 text-center"><span class="glyphicon glyphicon-phone"></span></div> 
                                <div class="col-xs-10">+91-9494074924</div>
                            </div>

                            <div class='row'>
                                <div class="col-xs-2 text-center"><span class="glyphicon glyphicon-map-marker"></span></div> 
                                <div class="col-xs-10">Hyderabad</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 contactinfo">
                        <div class="formdata">
                            <h2>Contact Me:</h2>

                            <?php
                            if (isset($_POST["email"])) {

                                $name = strip_tags(htmlspecialchars($_POST['name']));
                                $email_address = strip_tags(htmlspecialchars($_POST['email']));
                                $message = strip_tags(htmlspecialchars($_POST['message']));
                                $to = 'ramanjaneya219@gmail.com';
                                $email_subject = "Website Contact Form:  $name";
                            $email_body = '<html><body><table width="100%" style="border-collapse: collapse;font-size:15px;border:1px solid #3a5896;" cellpadding="10"><tbody>';
                              $email_body .=' <tr style="background:hsla(0,0%,2%,0.3);text-align:center; border: 1px solid #3a5896"><td colspan="6" style=" border: 1px solid #3a5896"><img src="http://ramthecoder.online/images/RAM-LOGO-PNG.png" width="100" alt="http://ramthecoder.online/" ></td></tr>';
                            $email_body .='<tr style="text-align:center; border: 1px solid #3a5896"><td colspan="2" style=" border: 1px solid #3a5896"><b>Name</b></td><td style=" border: 1px solid #3a5896">' . $name . '</td></tr>';
                           $email_body .='<tr style="text-align:center; border: 1px solid #3a5896"><td colspan="2" style=" border: 1px solid #3a5896"><b>Email</b></td><td style=" border: 1px solid #3a5896">' . $email_address . '</td></tr>';
                            $email_body .='<tr style="text-align:center; border: 1px solid #3a5896"><td colspan="2" style=" border: 1px solid #3a5896"><b>Message</b></td><td style=" border: 1px solid #3a5896">' . $message . '</td></tr>';
                           $email_body .='</tbody></table></body></html>';
                            
$headers = "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
$headers .= "From: ramanjaneya219@gmail.com\n";
                                $headers .= "Reply-To: $email_address";
                                
                                if(mail($to, $email_subject, $email_body, $headers)){
                                        $successMsg = 'Email has sent successfully.';
                                        echo $successMsg;
                                        
                                }
                                else{
                                        $successMsg = 'Email has falied.';
                                         echo $successMsg;
                                       
                                }

                              
                            } else {
                                ?>                
                                <form method="POST">

                                    <div class="form-group">
                                        <label for="text">Name:</label>
                                        <input type="text" class="form-control" id="text" placeholder="Enter Your Name" name="name" required>
                                    </div>

                                    <div class="form-group">
                                        <label for="email">Email:</label>
                                        <input type="email" class="form-control" id="email" placeholder="Enter email" name="email" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="message">Message:</label>

                                        <textarea id="message" class="form-control" placeholder="Enter Your Message Here" name="message" required></textarea>
                                    </div>

                                    <button type="submit" class="btn btn-default">Submit</button>
                                </form>
                                <?php
                            }
                            ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--**************************End Contact Section**************************************--> 


        <script type="text/javascript">
            WebFontConfig = {google: {families: ['Poppins|Source+Sans+Pro', 'Playfair+Display', 'Lobster']}};
            (function () {
                var wf = document.createElement('script');
                wf.src = ('https:' == document.location.protocol ? 'https' : 'http') + '://ajax.googleapis.com/ajax/libs/webfont/1.5.18/webfont.js';
                wf.type = 'text/javascript';
                wf.async = 'true';
                var s = document.getElementsByTagName('script')[0];
                s.parentNode.insertBefore(wf, s);
            })();</script>
        <script>
            $(document).ready(function () {
                // Add smooth scrolling to all links in navbar + footer link
                $(".navbar a, footer a[href='#myPage']").on('click', function (event) {
                    // Make sure this.hash has a value before overriding default behavior
                    if (this.hash !== "") {
                        // Prevent default anchor click behavior
                        event.preventDefault();
                        // Store hash
                        var hash = this.hash;
                        // Using jQuery's animate() method to add smooth page scroll
                        // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
                        $('html, body').animate({
                            scrollTop: $(hash).offset().top
                        }, 900, function () {

                            // Add hash (#) to URL when done scrolling (default click behavior)
                            window.location.hash = hash;
                        });
                    } // End if
                });
                $(window).scroll(function () {
                    $(".slideanim").each(function () {
                        var pos = $(this).offset().top;
                        var winTop = $(window).scrollTop();
                        if (pos < winTop + 600) {
                            $(this).addClass("slide");
                        }
                    });
                });
            })
        </script>
    </body>

</html>





