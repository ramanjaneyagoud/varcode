<!doctype html>
<head>
    <title>About Us | Freelancing web developer in Hyderabad.</title>
    <?php include("header.php"); ?>
        <div class="container">
             <h2 class="text-center mt-5">Contact Me</h2>
            <div class="row">
               <div class="col-sm-6 mt-2 mb-2">
                   <form class="" action="insert.php" method="POST">
                       <div class="form-group">
                           <label>First Name:</label>
                           <input type="text" name="name" class="form-control" required/>
                       </div>
                       <div class="form-group">
                           <label>Email:</label>
                           <input type="email" name="email" class="form-control" required/>
                       </div>
                       <div class="form-group">
                           <label>Phone:</label>
                           <input type="tel" name="phone" class="form-control"/>
                       </div>
                       <div class="form-group">
                           <label>Description:</label>
                           <textarea class="form-control" name="message" required></textarea>
                       </div>
                           <input type="submit"  class="btn btn-primary px-5 py-2" value="Submit" name="submit"/>
                   </form>
               </div>
            </div>
        </div>        
    
      <?php include("footer.php"); ?>